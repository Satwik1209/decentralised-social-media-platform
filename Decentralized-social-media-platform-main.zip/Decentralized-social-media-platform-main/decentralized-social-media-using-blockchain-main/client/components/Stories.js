function Stories(){
    return(
        <div>
            
        </div>
    )
}
export default Stories;