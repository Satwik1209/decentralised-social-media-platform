import {defineCliConfig} from 'sanity/cli'

export default defineCliConfig({
  api: {
    projectId: 'bogpqmqd',
    dataset: 'production'
  }
})
