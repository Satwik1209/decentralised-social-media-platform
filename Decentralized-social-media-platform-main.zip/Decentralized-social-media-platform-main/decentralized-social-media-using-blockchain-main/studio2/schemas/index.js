import { userSchema } from './userSchema'
import { tweetSchema } from './tweetSchema'
import { postSchema } from './postSchema'
export const schemaTypes = [userSchema,tweetSchema,postSchema]
